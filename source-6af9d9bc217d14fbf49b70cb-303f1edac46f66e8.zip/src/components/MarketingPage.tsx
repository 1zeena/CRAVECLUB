import { useRef, useState } from 'react'

type Snack = {
  id: string
  name: string
  short: string
  title: string
  description: string
  price: number
  color: string
  options: string[]
  allergens: string
}
const snacks: Snack[] = [
  {
    id: 'cookie',
    name: 'The Cookie',
    short: 'GOOEY. CHUNKY. UNREASONABLE.',
    title: 'CHUNK OF\nHAPPINESS.',
    description:
      'Crisp on the outside. Soft in all the right places. Loaded with big chocolate chunks and absolutely zero restraint.',
    price: 4.5,
    color: '#dce9b0',
    options: ['Classic choc chunk', 'Sea salt finish'],
    allergens:
      'Recipe and allergen details will be confirmed before ordering opens.',
  },
  {
    id: 'brownie',
    name: 'The Brownie',
    short: 'A LITTLE DARK. VERY HANDSOME.',
    title: 'DARK SIDE.\nSOFT CENTRE.',
    description:
      'Deep, dark chocolate. A crackly top. That gloriously fudgy middle. This is your permission to get a little messy.',
    price: 5,
    color: '#dab6c5',
    options: ['Original fudge', 'Chocolate drizzle'],
    allergens:
      'Recipe and allergen details will be confirmed before ordering opens.',
  },
  {
    id: 'fries',
    name: 'The Long Fries',
    short: 'LONG FRIES. SHORT SELF-CONTROL.',
    title: 'LONG STORY.\nEXTRA CRISPY.',
    description:
      'Ridiculously long, golden fries with a serious crunch. Made for dipping, sharing, and immediately regretting the sharing.',
    price: 5.5,
    color: '#f3bc7a',
    options: ['Sea salt', 'Smoky spice'],
    allergens:
      'Recipe and allergen details will be confirmed before ordering opens.',
  },
  {
    id: 'corn',
    name: 'The Butter Corn',
    short: 'GOLDEN LITTLE MOOD BOOSTERS.',
    title: 'BUTTER\nTOGETHER.',
    description:
      'Sweet golden kernels, a generous melt of butter, and a little seasoning magic. Sunshine, by the spoonful.',
    price: 4,
    color: '#e9d985',
    options: ['Classic butter', 'Chilli butter'],
    allergens:
      'Recipe and allergen details will be confirmed before ordering opens.',
  },
]
const food = (id: string, width = 800) =>
  import.meta.env.DEV
    ? `/img/${id}.png`
    : `/.netlify/images?url=/img/${id}.png&w=${width}&fm=webp&q=85`
const money = (n: number) => `$${n.toFixed(2)}`
function Star({ className = '' }: { className?: string }) {
  return (
    <svg
      className={className}
      viewBox="0 0 100 100"
      fill="currentColor"
      aria-hidden="true"
    >
      <path d="M50 0 59 32 85 15 68 41 100 50 68 59 85 85 59 68 50 100 41 68 15 85 32 59 0 50 32 41 15 15 41 32Z" />
    </svg>
  )
}
function Arrow() {
  return <span aria-hidden="true">↗</span>
}
type BagItem = {
  key: string
  name: string
  option: string
  price: number
  quantity: number
  id: string
}
export function MarketingPage() {
  const [active, setActive] = useState(0)
  const [option, setOption] = useState(snacks[0].options[0])
  const [bag, setBag] = useState<BagItem[]>([])
  const [notice, setNotice] = useState('')
  const [copied, setCopied] = useState(false)
  const dialog = useRef<HTMLDialogElement>(null)
  const hero = useRef<HTMLElement>(null)
  const snack = snacks[active]
  const count = bag.reduce((n, item) => n + item.quantity, 0)
  function select(index: number) {
    setCopied(false)
    setActive(index)
    setOption(snacks[index].options[0])
    setNotice('')
  }
  function add() {
    setCopied(false)
    const key = `${snack.id}-${option}`
    setBag((items) =>
      items.some((i) => i.key === key)
        ? items.map((i) =>
            i.key === key ? { ...i, quantity: i.quantity + 1 } : i,
          )
        : [
            ...items,
            {
              key,
              id: snack.id,
              name: snack.name,
              option,
              price: snack.price,
              quantity: 1,
            },
          ],
    )
    setNotice(`${snack.name} added. Good choice.`)
  }
  function changeQuantity(key: string, delta: number) {
    setCopied(false)
    setBag((items) =>
      items
        .map((i) =>
          i.key === key ? { ...i, quantity: i.quantity + delta } : i,
        )
        .filter((i) => i.quantity > 0),
    )
  }
  return (
    <>
      <a className="skip-link" href="#menu">
        Skip to menu
      </a>
      <header className="header">
        <a className="mini-logo" href="#home" aria-label="Crave Club home">
          CRAVE
          <br />
          CLUB<span>®</span>
        </a>
        <nav aria-label="Main navigation">
          <a href="#menu">THE MENU</a>
          <a href="#club">THE CLUB</a>
          <a href="#club" className="social-link">
            GOOD FOOD. GOOD COMPANY. <Arrow />
          </a>
        </nav>
        <button
          className="bag-button"
          onClick={() => dialog.current?.showModal()}
        >
          YOUR BAG <span>{count.toString().padStart(2, '0')}</span>
        </button>
      </header>
      <main>
        <section
          className="hero"
          id="home"
          ref={hero}
          onPointerMove={(e) => {
            if (e.pointerType === 'mouse') {
              const r = e.currentTarget.getBoundingClientRect()
              hero.current?.style.setProperty(
                '--mx',
                `${(e.clientX - r.left - r.width / 2) * 0.018}px`,
              )
              hero.current?.style.setProperty(
                '--my',
                `${(e.clientY - r.top - r.height / 2) * 0.018}px`,
              )
            }
          }}
          onPointerLeave={() => {
            hero.current?.style.setProperty('--mx', '0px')
            hero.current?.style.setProperty('--my', '0px')
          }}
        >
          <div className="hero-topline">
            <span>GOOD FOOD. BAD SELF-CONTROL.</span>
            <span>INDEPENDENT SNACK CULTURE ↙</span>
          </div>
          <h1 className="hero-logo">
            CRAVE CLUB<span>®</span>
          </h1>
          <div className="hero-copy">
            <span className="little-star">✳</span>
            <h2>
              WARNING:
              <br />
              HIGHLY CRAVEABLE.
            </h2>
            <p>
              Sweet. Savoury. Slightly out of control.
              <br />
              Welcome to your new favourite craving.
            </p>
            <a className="pill dark" href="#menu">
              FEED YOUR CRAVING <Arrow />
            </a>
          </div>
          <div
            className="food-world"
            aria-label="Chocolate cookies, fudgy brownies and crispy golden fries"
          >
            <img
              className="hero-food hero-cookie"
              src={food('cookie')}
              alt="Broken chocolate chunk cookie with a gooey centre"
              fetchPriority="high"
              width="800"
              height="800"
            />
            <img
              className="hero-food hero-fries"
              src={food('fries', 650)}
              alt="Extra-long golden fries in a red sleeve"
              width="650"
              height="650"
            />
            <img
              className="hero-food hero-brownie"
              src={food('brownie', 650)}
              alt="Stacked fudgy chocolate brownies"
              width="650"
              height="650"
            />
            <span className="sticker fresh">
              FRESHLY
              <br />
              <b>CRAVED</b>
              <span>✦ ✦ ✦</span>
            </span>
            <a href="#club" className="sticker round">
              100%
              <br />
              <b>CRAVE</b>
              <br />
              WORTHY
            </a>
            <span className="handwriting">
              a little bite.
              <br />a big obsession. <span>⤵</span>
            </span>
            <Star className="hero-star" />
          </div>
          <div className="hero-bottom">
            <span>MADE FOR YOUR “JUST ONE MORE” MOMENT.</span>
            <a href="#menu">
              SCROLL TO SNACK <span>↓</span>
            </a>
          </div>
        </section>
        <div className="ticker" aria-hidden="true">
          <div>
            {Array.from({ length: 6 }, (_, i) => (
              <span key={i}>
                BIG CRAVINGS <Star /> NO BORING BITES <Star />
              </span>
            ))}
          </div>
        </div>
        <section id="menu" className="menu-section">
          <div className="section-label">
            <span>01 / THE CRAVING STATION</span>
            <span>SELECT. CUSTOMISE. GIVE IN.</span>
          </div>
          <div className="menu-heading">
            <h2>
              PICK YOUR
              <br />
              <span>WEAKNESS.</span>
            </h2>
            <p>
              Four very good reasons to lose self-control.
              <br />
              Go on. Push a button.
            </p>
            <Star />
          </div>
          <div
            className="snack-machine"
            style={{ backgroundColor: snack.color }}
          >
            <div className="snack-select" aria-label="Choose your snack">
              {snacks.map((item, index) => (
                <button
                  key={item.id}
                  aria-pressed={active === index}
                  onClick={() => select(index)}
                >
                  <span className="snack-number">0{index + 1}</span>
                  <span>{item.name}</span>
                  <span aria-hidden="true">{active === index ? '↗' : '+'}</span>
                </button>
              ))}
              <div className="machine-note">
                <span className="status-dot" /> CRAVING SYSTEM: ONLINE
              </div>
            </div>
            <div className="product-stage" key={snack.id}>
              <span className="stage-word">
                {snack.id === 'cookie'
                  ? 'OOEY'
                  : snack.id === 'brownie'
                    ? 'FUDGY'
                    : snack.id === 'fries'
                      ? 'CRISPY'
                      : 'GOLDEN'}
              </span>
              <img
                src={food(snack.id)}
                alt={snack.name}
                loading="lazy"
                width="800"
                height="800"
              />
              <span className="product-tag">
                CERTIFIED
                <br />
                CLUB FAVOURITE ↗
              </span>
            </div>
            <div className="product-info">
              <p className="eyebrow">{snack.short}</p>
              <h3>{snack.title}</h3>
              <p>{snack.description}</p>
              <fieldset>
                <legend>MAKE IT YOURS</legend>
                {snack.options.map((o) => (
                  <button
                    key={o}
                    className={o === option ? 'option selected' : 'option'}
                    aria-pressed={o === option}
                    onClick={() => setOption(o)}
                  >
                    {o}
                  </button>
                ))}
              </fieldset>
              <button className="pill dark add-button" onClick={add}>
                ADD TO BAG — {money(snack.price)}{' '}
                <span aria-hidden="true">+</span>
              </button>
              <span className="add-notice" role="status">
                {notice || 'A little craving. A very good decision.'}
              </span>
              <small>{snack.allergens}</small>
            </div>
          </div>
          <p className="menu-footnote">
            A taste of what’s coming. Sample menu & USD prices. Online ordering
            opens soon.
          </p>
        </section>
        <section className="club-section" id="club">
          <div className="section-label">
            <span>02 / NOT A DIET. A PERSONALITY.</span>
            <span>WELCOME TO THE CLUB.</span>
          </div>
          <div className="club-layout">
            <div className="club-art">
              <span className="orbit-text">GOOD TASTE. GREAT COMPANY.</span>
              <div className="smiley">
                <span className="eye" />
                <span className="eye" />
                <span className="smile" />
              </div>
              <span className="club-sticker">
                JOIN THE
                <br />
                CLUB <Arrow />
              </span>
              <Star />
            </div>
            <div className="club-copy">
              <h2>
                WE TAKE
                <br />
                CRAVINGS
                <br />
                <em>PERSONALLY.</em>
              </h2>
              <p>
                For the sweet tooths. The salty snackers. The “can I have a
                bite?” people. The ones already thinking about their next snack.
              </p>
              <p>
                CRAVE CLUB is our little universe of big flavours, happy
                accidents, and food that makes an ordinary day a whole lot
                better. No secret handshake. Just good taste.
              </p>
              <a className="pill lime" href="#menu">
                YOU’RE ONE OF US <Arrow />
              </a>
            </div>
          </div>
        </section>
        <section className="last-bite">
          <span>STILL THINKING ABOUT IT?</span>
          <a href="#menu">
            GIVE IN.
            <Arrow />
          </a>
          <p>Your next favourite bite is right up there.</p>
        </section>
      </main>
      <footer>
        <a className="footer-logo" href="#home">
          CRAVE CLUB®
        </a>
        <div>
          <span>INDEPENDENT FOOD. COLLECTIVE OBSESSION.</span>
          <span>© {new Date().getFullYear()} CRAVE CLUB</span>
        </div>
        <a href="#home">BACK TO TOP ↑</a>
      </footer>
      <dialog
        ref={dialog}
        className="bag-dialog"
        aria-labelledby="bag-title"
        onClick={(e) => {
          if (e.target === e.currentTarget) dialog.current?.close()
        }}
      >
        <div className="bag-head">
          <h2 id="bag-title">YOUR CRAVINGS.</h2>
          <button
            aria-label="Close bag"
            onClick={() => dialog.current?.close()}
          >
            ×
          </button>
        </div>
        {bag.length ? (
          <>
            <p className="bag-intro">
              Excellent taste. Here’s your snack lineup.
            </p>
            <div className="bag-items">
              {bag.map((item) => (
                <div className="bag-item" key={item.key}>
                  <img src={food(item.id, 180)} alt="" width="90" height="90" />
                  <div>
                    <h3>{item.name}</h3>
                    <p>{item.option}</p>
                    <div className="quantity">
                      <button
                        aria-label={`Remove one ${item.name}`}
                        onClick={() => changeQuantity(item.key, -1)}
                      >
                        −
                      </button>
                      <span>{item.quantity}</span>
                      <button
                        aria-label={`Add one ${item.name}`}
                        onClick={() => changeQuantity(item.key, 1)}
                      >
                        +
                      </button>
                    </div>
                  </div>
                  <b>{money(item.price * item.quantity)}</b>
                </div>
              ))}
            </div>
            <div className="bag-total">
              <span>SAMPLE SUBTOTAL</span>
              <b>{money(bag.reduce((n, i) => n + i.price * i.quantity, 0))}</b>
            </div>
            <p className="ordering-note">
              The kitchen is warming up. Online ordering isn’t open yet — this
              bag is a preview, and no order or payment is taken.
            </p>
            <button
              className="pill dark"
              onClick={async () => {
                try {
                  await navigator.clipboard.writeText(
                    bag
                      .map((i) => `${i.quantity} × ${i.name} (${i.option})`)
                      .join('\n'),
                  )
                  setCopied(true)
                } catch {
                  setCopied(false)
                  setNotice(
                    'Copy unavailable in this browser. You can select the bag text instead.',
                  )
                }
              }}
            >
              {copied ? 'CRAVINGS COPIED ✓' : 'COPY YOUR SNACK LIST'} <Arrow />
            </button>
            <p role="status">{notice.startsWith('Copy') ? notice : ''}</p>
          </>
        ) : (
          <div className="empty-bag">
            <Star />
            <h3>
              SO MUCH ROOM
              <br />
              FOR GOOD THINGS.
            </h3>
            <p>Your bag is waiting for its first craving.</p>
            <button
              className="pill dark"
              onClick={() => {
                dialog.current?.close()
                document.getElementById('menu')?.scrollIntoView()
              }}
            >
              EXPLORE THE MENU <Arrow />
            </button>
          </div>
        )}
      </dialog>
    </>
  )
}
