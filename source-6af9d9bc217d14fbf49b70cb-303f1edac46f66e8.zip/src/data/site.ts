export const site = {
  name: 'CRAVE CLUB — Give in to the craving',
  description:
    'Enter the CRAVE CLUB universe. Explore outrageously good cookies, fudgy brownies, golden corn and extra-long fries. Warning: highly craveable.',
}
